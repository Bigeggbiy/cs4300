# task4.py
def calculate_discount(price, discount):
    return price - (price * discount / 100)