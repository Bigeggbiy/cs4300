# test_task7.py
from task7 import calculate_mean

def test_calculate_mean():
    assert calculate_mean([1, 2, 3, 4]) == 2.5