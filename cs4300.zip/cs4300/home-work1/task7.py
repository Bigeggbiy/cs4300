# task7.py
import numpy as np

def calculate_mean(data):
    return np.mean(data)