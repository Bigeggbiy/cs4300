# task2.py
def example_data_types():
    return {
        "integer": 42,
        "float": 3.14,
        "string": "Hello",
        "boolean": True,
    }