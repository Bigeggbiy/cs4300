# test_task6.py
from task6 import count_words

def test_count_words():
    assert count_words("task6_read_me.txt") == 88